import Home from "@/app/(afterLogin)/home/page";
import TweetModal from "@/app/(afterLogin)/@modal/(.)compose/tweet/page";

export default function Page() {
  return (
    <>
      <Home />
      <TweetModal />
    </>
  )
}
