import SignupModal from "@/app/(beforeLogin)/_component/SignupModal";

export default function Signup() {
  return (
    <>
      난 가로채기지롱 ㅋㅋ
      <SignupModal/>
    </>
  )
}
