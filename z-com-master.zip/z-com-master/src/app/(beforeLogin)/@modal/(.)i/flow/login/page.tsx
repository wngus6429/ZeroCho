import LoginModal from "@/app/(beforeLogin)/_component/LoginModal";

export default function Page() {
  return (
    <>
      난 가로채기지롱 ㅋㅋ
      <LoginModal />
    </>
  );
}