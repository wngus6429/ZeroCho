export interface Hashtag {
  tagId: number,
  title: string,
  count: number
}