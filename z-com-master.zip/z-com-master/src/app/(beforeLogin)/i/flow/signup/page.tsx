import SignupModal from "@/app/(beforeLogin)/_component/SignupModal";

export default function Signup() {
  return (
    <SignupModal />
  )
}
